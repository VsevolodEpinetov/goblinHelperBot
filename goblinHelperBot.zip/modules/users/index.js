const { Composer } = require('telegraf')

module.exports = Composer.compose([
  require('./commands/start'),
  require('./actions/requestAddUser'),
  require('./actions/setRole'),
  require('./actions/userMenu'),
  require('./actions/userMonths'),
  require('./actions/sendPayment'),
  require('./actions/confirmPayment'),
  require('./actions/userKickstarters'),
  require('./actions/getKickstarterForTicket'),
  require('./actions/showPurchasedKickstarters'),
  require('./actions/sendFilesKickstarter'),
])